import express from 'express';

const app = express();
app.use(express.json({ limit: '20kb' }));

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'LinkPlay backend' });
});

app.post('/resolve', async (req, res) => {
  const { shareUrl } = req.body ?? {};

  if (typeof shareUrl !== 'string' || !isSupportedShareUrl(shareUrl)) {
    return res.status(400).json({ error: 'Invalid or unsupported TeraBox URL.' });
  }

  // TODO: Integrate an official, authorized TeraBox API here.
  // The integration must verify the share and return a permitted HLS stream URL.
  // Never scrape private endpoints, bypass passwords, or defeat DRM/access controls.
  return res.status(501).json({
    error: 'TeraBox API integration is not configured. Add authorized API credentials and implementation.'
  });
});

function isSupportedShareUrl(value) {
  try {
    const url = new URL(value);
    const host = url.hostname.toLowerCase();
    return url.protocol === 'https:' &&
      (host.endsWith('terabox.com') ||
       host.endsWith('1024tera.com') ||
       host.endsWith('teraboxapp.com'));
  } catch {
    return false;
  }
}

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`LinkPlay backend listening on ${port}`));
