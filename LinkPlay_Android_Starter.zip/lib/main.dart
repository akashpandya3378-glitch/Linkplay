import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

void main() => runApp(const LinkPlayApp());

class LinkPlayApp extends StatelessWidget {
  const LinkPlayApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LinkPlay',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7C5CFC),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF101018),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _linkController = TextEditingController();
  VideoPlayerController? _videoController;
  bool _loading = false;
  String? _error;

  // Replace with your deployed HTTPS backend URL after deployment.
  static const String backendBaseUrl = 'https://YOUR-BACKEND-DOMAIN';

  Future<void> _pasteLink() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text != null) {
      _linkController.text = data!.text!.trim();
    }
  }

  bool _looksLikeTeraBoxLink(String value) {
    final uri = Uri.tryParse(value);
    if (uri == null || !uri.hasScheme || !uri.hasAuthority) return false;
    final host = uri.host.toLowerCase();
    return host.contains('terabox.com') ||
        host.contains('1024tera.com') ||
        host.contains('teraboxapp.com');
  }

  Future<void> _playVideo() async {
    FocusScope.of(context).unfocus();
    final link = _linkController.text.trim();

    if (!_looksLikeTeraBoxLink(link)) {
      setState(() => _error = 'Please enter a valid TeraBox sharing link.');
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      // The backend must use an official/authorized TeraBox integration.
      // A normal share URL is not itself a playable video stream URL.
      final response = await http.post(
        Uri.parse('$backendBaseUrl/resolve'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'shareUrl': link}),
      );

      if (response.statusCode != 200) {
        throw Exception(
          'The video service is not configured yet '
          '(server status ${response.statusCode}).',
        );
      }

      final body = jsonDecode(response.body) as Map<String, dynamic>;
      final streamUrl = body['streamUrl'] as String?;
      if (streamUrl == null || streamUrl.isEmpty) {
        throw Exception('No authorized video stream was returned.');
      }

      final nextController = VideoPlayerController.networkUrl(
        Uri.parse(streamUrl),
      );
      await nextController.initialize();
      await _videoController?.dispose();

      if (!mounted) {
        await nextController.dispose();
        return;
      }
      setState(() => _videoController = nextController);
      await nextController.play();
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _linkController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _videoController;
    return Scaffold(
      appBar: AppBar(
        title: const Text('LinkPlay'),
        centerTitle: true,
        actions: [
          IconButton(
            tooltip: 'Clear',
            onPressed: () {
              _linkController.clear();
              setState(() => _error = null);
            },
            icon: const Icon(Icons.clear_all),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 18),
          const Icon(Icons.play_circle_fill, size: 76, color: Color(0xFF9B83FF)),
          const SizedBox(height: 12),
          Text(
            'Play your shared video',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            'Paste a TeraBox sharing link below. Playback works when an authorized video stream is available.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Colors.white70,
                ),
          ),
          const SizedBox(height: 28),
          TextField(
            controller: _linkController,
            keyboardType: TextInputType.url,
            decoration: InputDecoration(
              hintText: 'Paste TeraBox link here',
              prefixIcon: const Icon(Icons.link),
              filled: true,
              fillColor: const Color(0xFF1D1D2A),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _pasteLink,
            icon: const Icon(Icons.content_paste),
            label: const Text('Paste link'),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: _loading ? null : _playVideo,
            icon: _loading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.play_arrow),
            label: Text(_loading ? 'Checking link...' : 'Play video'),
            style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(52),
            ),
          ),
          if (_error != null) ...[
            const SizedBox(height: 16),
            Text(_error!, style: const TextStyle(color: Colors.orangeAccent)),
          ],
          if (controller != null && controller.value.isInitialized) ...[
            const SizedBox(height: 24),
            AspectRatio(
              aspectRatio: controller.value.aspectRatio,
              child: VideoPlayer(controller),
            ),
            VideoProgressIndicator(controller, allowScrubbing: true),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  onPressed: () => controller.value.isPlaying
                      ? controller.pause()
                      : controller.play(),
                  icon: Icon(controller.value.isPlaying
                      ? Icons.pause
                      : Icons.play_arrow),
                ),
              ],
            ),
          ],
          const SizedBox(height: 28),
          const Text(
            'LinkPlay only supports videos you are authorized to access. '
            'It does not bypass passwords, DRM, or sharing restrictions.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white54, fontSize: 12),
          ),
        ],
      ),
    );
  }
}
